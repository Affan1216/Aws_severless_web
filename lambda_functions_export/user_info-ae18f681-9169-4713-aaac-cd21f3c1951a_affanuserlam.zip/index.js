const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();
const sns = new AWS.SNS(); 
const { v4: uuidv4 } = require('uuid');

const SNS_TOPIC_ARN = "arn:aws:sns:us-east-1:580139618706:user_sns"; 

exports.handler = async (event) => {
    let body;
    let response;

    console.log("Received event: ", JSON.stringify(event, null, 2)); 

    try {
        switch (event.routeKey) {
            case 'POST /user-login':
                body = JSON.parse(event.body);
                const loginParams = {
                    TableName: 'User_info',
                    FilterExpression: 'username = :username AND password = :password',
                    ExpressionAttributeValues: {
                        ':username': body.username,
                        ':password': body.password,
                    },
                };
                const loginResult = await dynamo.scan(loginParams).promise();
                if (loginResult.Items.length > 0) {
                    response = {
                        statusCode: 200,
                        body: JSON.stringify(loginResult.Items),
                    };
                    await sns.publish({
                        Message: `User ${body.username} has logged in.`,
                        TopicArn: SNS_TOPIC_ARN
                    }).promise();
                } else {
                    response = {
                        statusCode: 401,
                        body: JSON.stringify({ error: 'Invalid username or password' }),
                    };
                }
                break;

            case 'POST /add-user':
                body = JSON.parse(event.body);
                const userid = uuidv4(); 
                const addUserParams = {
                    TableName: 'User_info',
                    Item: {
                        userid: userid,
                        address: body.address,
                        createdate: body.createdate,
                        email: body.email,
                        name: body.name,
                        password: body.password,
                        phonenumber: body.phonenumber,
                        username: body.username,
                    },
                };
                await dynamo.put(addUserParams).promise();
                response = {
                    statusCode: 201,
                    body: JSON.stringify({ message: 'User added successfully', userid: userid }),
                };
                await sns.publish({
                    Message: `New user registered: ${body.username}`,
                    TopicArn: SNS_TOPIC_ARN
                }).promise();
                break;

            case 'PUT /user-profile/{userid}':
                body = JSON.parse(event.body);
                console.log("Updating user with ID: ", event.pathParameters.userid);  // Log the user ID
                console.log("Update data: ", body);  

                const updateUserParams = {
                    TableName: 'User_info',
                    Key: { userid: event.pathParameters.userid },
                    UpdateExpression: 'set address = :address, createdate = :createdate, email = :email, #name = :name, password = :password, phonenumber = :phonenumber, username = :username',
                    ExpressionAttributeValues: {
                        ':address': body.address,
                        ':createdate': body.createdate,
                        ':email': body.email,
                        ':name': body.name,
                        ':password': body.password,
                        ':phonenumber': body.phonenumber,
                        ':username': body.username,
                    },
                    ExpressionAttributeNames: {
                        '#name': 'name'
                    },
                    ReturnValues: 'UPDATED_NEW',
                };

                const updateResult = await dynamo.update(updateUserParams).promise();
                response = {
                    statusCode: 200,
                    body: JSON.stringify({ message: 'User profile updated successfully', updatedAttributes: updateResult.Attributes }),
                };
                break;

            case 'DELETE /user-profile/{userid}':
                const deleteUserParams = {
                    TableName: 'User_info',
                    Key: { userid: event.pathParameters.userid },
                };
                await dynamo.delete(deleteUserParams).promise();
                response = {
                    statusCode: 200,
                    body: JSON.stringify({ message: 'User profile deleted successfully' }),
                };
                break;

            case 'GET /user-profile/{userid}':
                const getUserParams = {
                    TableName: 'User_info',
                    Key: { userid: event.pathParameters.userid },
                };
                const getResult = await dynamo.get(getUserParams).promise();
                if (getResult.Item) {
                    response = {
                        statusCode: 200,
                        body: JSON.stringify(getResult.Item),
                    };
                } else {
                    response = {
                        statusCode: 404,
                        body: JSON.stringify({ error: 'User not found' }),
                    };
                }
                break;

            default:
                response = {
                    statusCode: 400,
                    body: JSON.stringify({ error: `Unsupported route: ${event.routeKey}` }),
                };
        }
    } catch (err) {
        console.error("Error: ", JSON.stringify(err, null, 2));  
        response = {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal Server Error' }),
        };
    }

    return response;
};
