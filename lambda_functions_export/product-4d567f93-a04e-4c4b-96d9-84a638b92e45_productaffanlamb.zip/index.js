const mysql = require('mysql');

const con = mysql.createConnection({
    host: "product.clwaock1d9ma.us-east-1.rds.amazonaws.com",
    user: "admin",
    password: "password",
    port: "3306",
    database: "product"
});

exports.handler = async (event) => {
    const response = {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin": "*", 
            "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS", 
            "Access-Control-Allow-Headers": "Content-Type,Authorization", 
        },
    };

    let sql;
    let params;
    let body;

    try {
        switch (event.routeKey) {
            case 'GET /product':
                sql = "SELECT * FROM product.Products;";
                const getResult = await queryDB(sql);
                response.body = JSON.stringify(getResult);
                break;

            case 'GET /product/{product_id}':
                const getProduct_id = event.pathParameters.product_id;
                sql = "SELECT * FROM product.Products WHERE product_id = ?;";
                params = [getProduct_id];
                const getProductResult = await queryDB(sql, params);
                response.body = JSON.stringify(getProductResult);
                break;

            case 'GET /user-products/{username}':
                const username = event.pathParameters.username;
                sql = "SELECT * FROM product.Products WHERE added_by = ?;";
                params = [username];
                const getUserProductsResult = await queryDB(sql, params);
                response.body = JSON.stringify(getUserProductsResult);
                break;

            case 'POST /product':
                body = JSON.parse(event.body);
                sql = "INSERT INTO product.Products (product_name, product_description, product_price, image_url, product_quantity, product_createdate, added_by) VALUES (?, ?, ?, ?, ?, NOW(), ?);";
                params = [
                    body.product_name,
                    body.product_description,
                    body.product_price,
                    body.image_url,
                    body.product_quantity,
                    body.added_by
                ];
                const addProductResult = await queryDB(sql, params);
                response.body = JSON.stringify({ message: "Product added", result: addProductResult });
                break;

            case 'DELETE /product/{product_id}':
                const deleteProduct_id = event.pathParameters.product_id;
                sql = "DELETE FROM product.Products WHERE product_id = ?;";
                params = [deleteProduct_id];
                const deleteProductResult = await queryDB(sql, params);
                response.body = JSON.stringify({ message: "Product deleted successfully", result: deleteProductResult });
                break;

            case 'PUT /product/{product_id}':
                body = JSON.parse(event.body);
                const updateProduct_id = event.pathParameters.product_id;
                sql = "UPDATE product.Products SET product_name = ?, product_description = ?, product_price = ?, image_url = ?, product_quantity = ? WHERE product_id = ? AND added_by = ?;";
                params = [
                    body.product_name,
                    body.product_description,
                    body.product_price,
                    body.image_url,
                    body.product_quantity,
                    updateProduct_id,
                    body.added_by
                ];
                const updateProductResult = await queryDB(sql, params);
                response.body = JSON.stringify({ message: "Product updated successfully", result: updateProductResult });
                break;

            default:
                response.statusCode = 400;
                response.body = JSON.stringify({ error: "Unsupported route: " + event.routeKey });
        }
    } catch (err) {
        console.error("Error:", err);
        response.statusCode = 500;
        response.body = JSON.stringify({
            error: err.message
        });
    }

    return response;
};

function queryDB(sql, params = []) {
    return new Promise((resolve, reject) => {
        con.query(sql, params, (err, result) => {
            if (err) {
                reject(err);
            } else {
                resolve(result);
            }
        });
    });
}
