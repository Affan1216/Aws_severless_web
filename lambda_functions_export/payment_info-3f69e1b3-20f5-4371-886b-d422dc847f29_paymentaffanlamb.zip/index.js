const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();
const sns = new AWS.SNS();
const { v4: uuidv4 } = require('uuid');

exports.handler = async (event, context, callback) => {
    let body;
    let response;

    try {
        switch (event.routeKey) {
            case 'POST /payment':
                body = JSON.parse(event.body);
                const paymentId = uuidv4();
                var putParams = {
                    TableName: 'payment',
                    Item: {
                        Paymentid: paymentId,
                        createdate: body.createdate,
                        payment_method: body.payment_method,
                        payment_status: body.payment_status,
                        price: body.price,
                        userid: body.userid
                    }
                };
                await dynamo.put(putParams).promise();

                // SNS notification
                const snsParams = {
                    Message: JSON.stringify({
                        default: `Payment for User ID: ${body.userid} was successful.`,
                        sms: `Payment for User ID: ${body.userid} was successful.`,
                        email: `Payment for User ID: ${body.userid} was successful.`
                    }),
                    Subject: 'Payment Successful',
                    TopicArn: 'arn:aws:sns:us-east-1:580139618706:paymenttopic',
                    MessageStructure: 'json'
                };

                try {
                    const snsResult = await sns.publish(snsParams).promise();
                    console.log(`SNS message sent: ${snsResult.MessageId}`);
                } catch (snsError) {
                    console.error(`Error sending SNS message: ${snsError}`);
                }
                response = {
                    statusCode: 201,
                    body: JSON.stringify({ message: 'Payment successfully created and notification sent' })
                };
                callback(null, response);
                break;

            case 'PUT /payment':
                body = JSON.parse(event.body);
                var updateParams = {
                    TableName: 'payment',
                    Key: { 
                        "Paymentid": body.Paymentid
                    },
                    UpdateExpression: "set createdate = :createdate, payment_method = :payment_method, payment_status = :payment_status, price = :price, userid = :userid",
                    ExpressionAttributeValues: {
                        ":createdate": body.createdate,
                        ":payment_method": body.payment_method,
                        ":payment_status": body.payment_status,
                        ":price": body.price,
                        ":userid": body.userid
                    },
                    ReturnValues: "UPDATED_NEW"
                };
                const result = await dynamo.update(updateParams).promise();
                response = {
                    statusCode: 200,
                    body: JSON.stringify({ message: 'Payment successfully updated', updatedAttributes: result.Attributes })
                };
                callback(null, response);
                break;

            case 'DELETE /payment':
                body = JSON.parse(event.body);
                var deleteParams = {
                    TableName: 'payment',
                    Key: { 
                        "Paymentid": body.Paymentid
                    }
                };
                await dynamo.delete(deleteParams).promise();
                response = {
                    statusCode: 200,
                    body: JSON.stringify({ message: 'Payment successfully deleted' })
                };
                callback(null, response);
                break;
                
            case 'GET /payments':
                var scanParams = {
                    TableName: 'payment'
                };
                const scanResult = await dynamo.scan(scanParams).promise();
                response = {
                    statusCode: 200,
                    body: JSON.stringify(scanResult.Items)
                };
                callback(null, response);
                break;

            case 'GET /payment/{Paymentid}':
                const paymentIdParam = event.pathParameters.Paymentid;
                var getParams = {
                    TableName: 'payment',
                    Key: { 
                        "Paymentid": paymentIdParam
                    }
                };
                const getResult = await dynamo.get(getParams).promise();
                if (getResult.Item) {
                    response = {
                        statusCode: 200,
                        body: JSON.stringify(getResult.Item)
                    };
                } else {
                    response = {
                        statusCode: 404,
                        body: JSON.stringify({ error: "Payment not found" })
                    };
                }
                callback(null, response);
                break;

            default:
                response = {
                    statusCode: 400,
                    body: JSON.stringify({ error: "Unsupported route: " + event.routeKey })
                };
                callback(null, response);
        }
    } catch (error) {
        console.error("Error:", error);
        response = {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal Server Error', details: error.message })
        };
        callback(null, response);
    }
};
