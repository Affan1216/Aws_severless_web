const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();
const { v4: uuidv4 } = require('uuid');

exports.handler = async (event, context) => {
    let body;
    let response;

    try {
        switch (event.routeKey) {
            case 'POST /add-order/{Userid}':
                body = JSON.parse(event.body);
                const orderid = uuidv4();  
                const addParams = {
                    TableName: 'Order',
                    Item: {
                        Orderid: orderid,
                        Userid: event.pathParameters.Userid, 
                        address: body.address,
                        createdate: body.createdate,
                        orderstatus: body.orderstatus,
                        price: body.price,
                        productid: body.productid,
                        quantity: body.quantity
                    }
                };
                await dynamo.put(addParams).promise();
                response = {
                    statusCode: 201,
                    body: JSON.stringify({ message: 'Order added successfully', Orderid: orderid })
                };
                break;

            case 'GET /orders':
                const scanParams = {
                    TableName: 'Order',
                };
                const scanResult = await dynamo.scan(scanParams).promise();
                response = {
                    statusCode: 200,
                    body: JSON.stringify(scanResult.Items)
                };
                break;

            case 'GET /order/{Orderid}/{Userid}':
                console.log("Received pathParameters:", event.pathParameters);
                const getParams = {
                    TableName: 'Order',
                    Key: {
                        'Orderid': event.pathParameters.Orderid,
                        'Userid': event.pathParameters.Userid
                    },
                };
                const getResult = await dynamo.get(getParams).promise();
                if (getResult.Item) {
                    response = {
                        statusCode: 200,
                        body: JSON.stringify(getResult.Item)
                    };
                } else {
                    response = {
                        statusCode: 404,
                        body: JSON.stringify({ error: 'Order not found' })
                    };
                }
                break;

            case 'PUT /order/{Orderid}/{Userid}':
                body = JSON.parse(event.body);
                const updateParams = {
                    TableName: 'Order',
                    Key: { "Orderid": event.pathParameters.Orderid, "Userid": event.pathParameters.Userid },
                    UpdateExpression: "set address = :address, createdate = :createdate, orderstatus = :orderstatus, price = :price, productid = :productid, quantity = :quantity",
                    ExpressionAttributeValues: {
                        ":address": body.address,
                        ":createdate": body.createdate,
                        ":orderstatus": body.orderstatus,
                        ":price": body.price,
                        ":productid": body.productid,
                        ":quantity": body.quantity
                    },
                    ReturnValues: "UPDATED_NEW"
                };
                await dynamo.update(updateParams).promise();
                response = {
                    statusCode: 200,
                    body: JSON.stringify({ message: 'Order updated successfully' })
                };
                break;

            case 'DELETE /order/{Orderid}/{Userid}':
                const deleteParams = {
                    TableName: 'Order',
                    Key: {
                        'Orderid': event.pathParameters.Orderid,
                        'Userid': event.pathParameters.Userid
                    },
                };
                await dynamo.delete(deleteParams).promise();
                response = {
                    statusCode: 200,
                    body: JSON.stringify({ message: 'Order deleted successfully' })
                };
                break;

            default:
                response = {
                    statusCode: 400,
                    body: JSON.stringify({ error: "Unsupported route: " + event.routeKey })
                };
        }
    } catch (err) {
        console.error("Error processing request:", err);
        response = {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal Server Error', details: err.message })
        };
    }
    return response;
};